package com.example.myassistant

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Gemini (Google AI Studio free tier) agent loop with function calling. */
class Agent(private val ctx: Context, private val tools: Tools) {
    var apiKey = ""
    var model = "gemini-2.5-flash"   // change in the app if AI Studio lists a newer free Flash model

    private val http = OkHttpClient.Builder().readTimeout(90, TimeUnit.SECONDS).build()
    private var contents = JSONArray()
    private val toolDecls: JSONArray = toGemini(tools.definitions())

    private val system = """You are a voice assistant running on the user's Android phone. Use the tools to act on the phone.
Your replies are spoken aloud: keep them to one or two short sentences, no markdown.
Break multi-part requests into several tool calls. Only call or message people the user explicitly named.
For photo searches, expand the request into many lowercase keywords and synonyms. Use device_status when asked why the phone is slow, hot or draining.
You cannot browse the web. If a tool says a permission is missing, tell the user what to enable."""

    fun reset() { contents = JSONArray() }

    suspend fun run(userText: String, status: (String) -> Unit): String = withContext(Dispatchers.IO) {
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", userText))))
        repeat(12) {
            val resp = call()
            val cand = resp.optJSONArray("candidates")?.optJSONObject(0)
                ?: return@withContext "No answer (${resp.optJSONObject("promptFeedback")?.optString("blockReason") ?: "empty response"})."
            val content = cand.optJSONObject("content") ?: return@withContext "No answer."
            val parts = content.optJSONArray("parts") ?: JSONArray()
            // Store parts verbatim (keeps any thought signatures Gemini needs for later turns)
            contents.put(JSONObject().put("role", "model").put("parts", parts))

            val calls = (0 until parts.length()).map { parts.getJSONObject(it) }.filter { it.has("functionCall") }
            if (calls.isEmpty()) {
                return@withContext (0 until parts.length()).map { parts.getJSONObject(it) }
                    .filter { it.has("text") }.joinToString(" ") { it.getString("text") }.ifBlank { "Done." }
            }
            val replies = JSONArray()
            for (p in calls) {
                val fc = p.getJSONObject("functionCall")
                val name = fc.getString("name")
                status("→ $name")
                val out = try { tools.execute(name, fc.optJSONObject("args") ?: JSONObject()) } catch (e: Exception) { "Error: ${e.message}" }
                replies.put(JSONObject().put("functionResponse",
                    JSONObject().put("name", name).put("response", JSONObject().put("result", out))))
            }
            contents.put(JSONObject().put("role", "user").put("parts", replies))
        }
        "I stopped after too many steps."
    }

    private fun call(): JSONObject {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("tools", toolDecls)
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        http.newCall(req).execute().use { r ->
            val s = r.body?.string() ?: ""
            if (r.code == 429) error("Free-tier rate limit reached. Wait a minute and try again.")
            if (!r.isSuccessful) error("API ${r.code}: ${s.take(300)}")
            return JSONObject(s)
        }
    }

    // ----- convert the tool schemas to Gemini's format -----
    private fun toGemini(defs: JSONArray): JSONArray {
        val decls = JSONArray()
        for (i in 0 until defs.length()) {
            val d = defs.getJSONObject(i)
            val schema = d.getJSONObject("input_schema")
            val decl = JSONObject().put("name", d.getString("name")).put("description", d.getString("description"))
            if (schema.getJSONObject("properties").length() > 0) decl.put("parameters", convert(schema))
            decls.put(decl)
        }
        return JSONArray().put(JSONObject().put("functionDeclarations", decls))
    }

    private fun convert(o: JSONObject): JSONObject {
        val r = JSONObject()
        for (k in o.keys()) {
            val v = o.get(k)
            if (k == "required" && v is JSONArray && v.length() == 0) continue
            when {
                k == "type" && v is String -> r.put(k, v.uppercase())
                v is JSONObject -> r.put(k, convert(v))
                else -> r.put(k, v)
            }
        }
        return r
    }
}
