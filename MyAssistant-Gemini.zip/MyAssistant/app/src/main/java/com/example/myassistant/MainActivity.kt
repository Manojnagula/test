package com.example.myassistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.util.Size
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var tts: TextToSpeech
    private lateinit var agent: Agent
    private lateinit var log: TextView
    private lateinit var keyField: EditText
    private lateinit var modelField: EditText
    private lateinit var input: EditText
    private lateinit var strip: LinearLayout
    private var recognizer: SpeechRecognizer? = null
    private val prefs by lazy { getSharedPreferences("prefs", MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        agent = Agent(applicationContext, Tools(applicationContext))
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts.language = Locale.getDefault() }
        buildUi()
        requestPerms()
        UiBridge.onImages = { uris -> runOnUiThread { showImages(uris) } }
        if (intent.getBooleanExtra("listen", false)) listen()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra("listen", false)) listen()
    }

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)) }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(dp(12), b.top + dp(12), dp(12), b.bottom + dp(12)); insets
        }
        keyField = EditText(this).apply {
            hint = "Gemini API key (aistudio.google.com)"; setText(prefs.getString("api_key", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        root.addView(keyField)
        modelField = EditText(this).apply {
            hint = "Model"; setText(prefs.getString("model", "gemini-2.5-flash"))
        }
        root.addView(modelField)

        val row1 = LinearLayout(this)
        row1.addView(btn("🎤 Speak") { listen() })
        row1.addView(btn("Index photos") { GalleryIndexWorker.enqueue(this); append("Indexing photos in background…") })
        root.addView(row1)
        val row2 = LinearLayout(this)
        row2.addView(btn("Accessibility") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        row2.addView(btn("Set as assistant") { startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) })
        row2.addView(btn("New chat") { agent.reset(); log.text = "" })
        root.addView(row2)

        val sendRow = LinearLayout(this)
        input = EditText(this).apply { hint = "Type a command"; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) }
        sendRow.addView(input)
        sendRow.addView(Button(this).apply { text = "Send"; setOnClickListener {
            val t = input.text.toString().trim(); if (t.isNotEmpty()) { input.setText(""); submit(t) } } })
        root.addView(sendRow)

        strip = LinearLayout(this)
        root.addView(HorizontalScrollView(this).apply { addView(strip) })

        log = TextView(this).apply { typeface = Typeface.DEFAULT; textSize = 15f }
        root.addView(ScrollView(this).apply {
            addView(log); layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        })
        setContentView(root)
    }

    private fun requestPerms() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS, Manifest.permission.READ_CALENDAR)
        p += if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
        val missing = p.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1)
    }

    private fun append(line: String) = runOnUiThread { log.append(line + "\n\n") }

    private fun submit(text: String) {
        val key = keyField.text.toString().trim()
        prefs.edit().putString("api_key", key).apply()
        agent.apiKey = key
        val model = modelField.text.toString().trim().ifBlank { "gemini-2.5-flash" }
        prefs.edit().putString("model", model).apply()
        agent.model = model
        append("You: $text")
        lifecycleScope.launch {
            val reply = try { agent.run(text) { append(it) } } catch (e: Exception) { "Error: ${e.message}" }
            append("Assistant: $reply")
            tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "reply")
        }
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { Toast.makeText(this, "Speech recognition unavailable", Toast.LENGTH_SHORT).show(); return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { append("Listening…") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(e: Int) { append("Speech error $e") }
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onResults(r: Bundle?) {
                    r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { submit(it) }
                }
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))
        }
    }

    private fun showImages(uris: List<Uri>) {
        strip.removeAllViews()
        uris.forEach { uri ->
            strip.addView(ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(120), dp(120)).apply { marginEnd = dp(6) }
                scaleType = ImageView.ScaleType.CENTER_CROP
                try { setImageBitmap(contentResolver.loadThumbnail(uri, Size(240, 240), null)) } catch (e: Exception) {}
                setOnClickListener {
                    startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "image/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                }
            })
        }
        if (uris.isEmpty()) strip.addView(TextView(this).apply { text = "No matching photos" })
    }

    override fun onDestroy() { recognizer?.destroy(); tts.shutdown(); UiBridge.onImages = null; super.onDestroy() }
}
