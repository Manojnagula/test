# My Assistant (Bixby-style Android agent)

Voice -> Gemini (function calling, free tier) -> Android actions. Open this folder in Android Studio (Ladybug or newer), let Gradle sync, run on your phone.

## First-run setup
1. Get a free key at https://aistudio.google.com (Get API key). Paste it in the app. If the default model name stops working, pick a current free Flash / Flash-Lite model listed in AI Studio and type it in the Model field. Personal testing only; for a shared app, put the key on your own backend.
2. Grant the permission prompts (mic, contacts, calendar, photos, phone).
3. Tap **Accessibility** and enable "My Assistant" (needed for screenshot, tapping, reading the screen).
4. Tap **Set as assistant** -> Default digital assistant app -> My Assistant (path varies on Realme UI).
5. Tap **Index photos** once (ideally while charging). Gallery search runs fully on-device.
6. Optional, for dark mode control: `adb shell pm grant com.example.myassistant android.permission.WRITE_SECURE_SETTINGS`
7. Realme/ColorOS: allow auto-start and set battery usage to "Unrestricted" for the app.

## Try
"Set an alarm for 6:30", "Call Mom", "Set brightness to 30", "Silent mode", "Open Spotify",
"Show photos with the beach", "Show my Aadhaar card", "Why is my phone hot?", "Turn on Wi-Fi" (opens quick settings and taps the tile).

## Privacy
- Photo labels and OCR text are stored only in the app's private database; only your spoken query and a result count go to Gemini. Note: Google may use free-tier inputs/outputs to improve its products.
- read_screen sends visible screen text to Gemini. Don't use it on banking or OTP screens.
- Messages are only drafted (you tap Send). Add confirmation prompts before extending destructive tools.

## Upgrading gallery search
ML Kit's built-in labels are coarse (beach, dog, tower...). For precise queries like "lighthouse", add a MobileCLIP/SigLIP TFLite model, store image embeddings in GalleryDb, and rank by cosine similarity in `GalleryDb.search`.

## Free-tier notes
The free tier is rate limited (requests per minute/day). A multi-step command uses several requests, so if you see a rate-limit message, wait a minute. Web search is not included.
