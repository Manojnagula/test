package com.mygoodlock.modules.StatusBar
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.mygoodlock.core.*

object StatusBar : GoodModule {
    override val id = "statusbar"; override val title = "StatusBar"
    override val summary = "Hide status-bar icons (needs ADB grant)"
    private val icons = listOf("alarm_clock", "nfc", "hotspot", "volume", "vpn", "rotate", "bluetooth", "wifi")
    @Composable override fun Screen() {
        val c = LocalContext.current
        val hidden = remember { mutableStateListOf<String>() }
        Column {
            if (!Secure.granted(c)) Text("Run once: adb shell pm grant com.mygoodlock android.permission.WRITE_SECURE_SETTINGS")
            icons.forEach { ic ->
                Row { Text(ic, Modifier.weight(1f))
                    Switch(ic in hidden, { on -> if (on) hidden.add(ic) else hidden.remove(ic)
                        Secure.put(c, "icon_blacklist", hidden.joinToString(",")) }) }
            }
        }
    }
}
