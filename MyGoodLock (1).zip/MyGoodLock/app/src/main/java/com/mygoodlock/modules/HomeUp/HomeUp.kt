package com.mygoodlock.modules.HomeUp
import android.content.Intent
import android.content.pm.ResolveInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import com.mygoodlock.core.*

object HomeUp : GoodModule {
    override val id = "homeup"; override val title = "HomeUp"
    override val summary = "Mini launcher with adjustable grid"
    @Composable override fun Screen() {
        val c = LocalContext.current
        var cols by remember { mutableIntStateOf(AppSettings.homeColumns) }
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Grid columns: $cols")
            Slider(cols.toFloat(), { cols = it.toInt(); AppSettings.homeColumns = cols }, valueRange = 3f..7f, steps = 3)
            Button({ c.startActivity(Intent(android.provider.Settings.ACTION_HOME_SETTINGS)) }) { Text("Set as default home") }
        }
    }
}

class HomeActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s); AppSettings.init(this); ThemeEngine.load()
        val pm = packageManager
        val apps: List<ResolveInfo> = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).sortedBy { it.loadLabel(pm).toString().lowercase() }
        setContent { MyTheme { Surface(Modifier.fillMaxSize()) {
            LazyVerticalGrid(GridCells.Fixed(AppSettings.homeColumns), Modifier.safeDrawingPadding(), contentPadding = PaddingValues(12.dp)) {
                items(apps.size) { i ->
                    val a = apps[i]
                    Column(Modifier.padding(6.dp).clickable {
                        pm.getLaunchIntentForPackage(a.activityInfo.packageName)?.let(::startActivity)
                    }, horizontalAlignment = Alignment.CenterHorizontally) {
                        Image(a.loadIcon(pm).toBitmap(96, 96).asImageBitmap(), null, Modifier.size(48.dp))
                        Text(a.loadLabel(pm).toString(), maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        } } }
    }
}
