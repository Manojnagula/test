package com.mygoodlock.core
import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings

/** Needs one-time: adb shell pm grant com.mygoodlock android.permission.WRITE_SECURE_SETTINGS */
object Secure {
    fun granted(c: Context) = c.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED
    fun put(c: Context, key: String, v: String) = runCatching { Settings.Secure.putString(c.contentResolver, key, v) }.getOrDefault(false)
    fun putInt(c: Context, key: String, v: Int) = runCatching { Settings.Secure.putInt(c.contentResolver, key, v) }.getOrDefault(false)
}
