package com.mygoodlock.modules.RegiStar
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.mygoodlock.core.GoodModule

object RegiStar : GoodModule {
    override val id = "registar"; override val title = "RegiStar"
    override val summary = "One-tap shortcuts to deep system settings"
    private val items = listOf(
        "Display" to Settings.ACTION_DISPLAY_SETTINGS, "Wi-Fi" to Settings.ACTION_WIFI_SETTINGS,
        "Battery" to Intent.ACTION_POWER_USAGE_SUMMARY, "Developer options" to Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS,
        "Default apps" to Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS, "Notifications" to Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS,
    )
    @Composable override fun Screen() {
        val c = LocalContext.current
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items.forEach { (n, a) -> OutlinedButton({ runCatching { c.startActivity(Intent(a)) } }, Modifier.fillMaxWidth()) { Text(n) } }
        }
    }
}
