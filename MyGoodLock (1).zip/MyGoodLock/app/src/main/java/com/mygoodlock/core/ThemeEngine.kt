package com.mygoodlock.core
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

object ThemeEngine {
    var accent by mutableIntStateOf(0)
    var dynamic by mutableStateOf(true)
    fun load() { accent = AppSettings.accent; dynamic = AppSettings.dynamic }
    fun setAccent(c: Int) { AppSettings.accent = c; accent = c; AppSettings.dynamic = false; dynamic = false }
    fun setDynamic(on: Boolean) { AppSettings.dynamic = on; dynamic = on }
}

@Composable
fun MyTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme(); val ctx = LocalContext.current
    val scheme = when {
        ThemeEngine.dynamic && Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme(primary = Color(ThemeEngine.accent))
        else -> lightColorScheme(primary = Color(ThemeEngine.accent))
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
