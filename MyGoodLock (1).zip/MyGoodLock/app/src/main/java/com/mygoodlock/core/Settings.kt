package com.mygoodlock.core
import android.content.Context
import android.content.SharedPreferences

object AppSettings {
    private lateinit var p: SharedPreferences
    fun init(c: Context) { p = c.getSharedPreferences("mgl", Context.MODE_PRIVATE) }
    var accent: Int get() = p.getInt("accent", 0xFF6750A4.toInt()); set(v) = p.edit().putInt("accent", v).apply()
    var dynamic: Boolean get() = p.getBoolean("dynamic", true); set(v) = p.edit().putBoolean("dynamic", v).apply()
    var homeColumns: Int get() = p.getInt("cols", 5); set(v) = p.edit().putInt("cols", v).apply()
}
