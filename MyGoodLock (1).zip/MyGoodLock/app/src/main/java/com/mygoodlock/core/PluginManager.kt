package com.mygoodlock.core
import androidx.compose.runtime.Composable
import com.mygoodlock.modules.HomeUp.HomeUp
import com.mygoodlock.modules.LockStar.LockStar
import com.mygoodlock.modules.NavBar.NavBar
import com.mygoodlock.modules.QuickPanel.QuickPanel
import com.mygoodlock.modules.RegiStar.RegiStar
import com.mygoodlock.modules.StatusBar.StatusBar
import com.mygoodlock.modules.ThemePark.ThemePark

interface GoodModule {
    val id: String; val title: String; val summary: String
    @Composable fun Screen()
}

object PluginManager {
    private val enabled = mutableSetOf<String>()
    val all: List<GoodModule> = listOf(ThemePark, LockStar, QuickPanel, HomeUp, NavBar, StatusBar, RegiStar)
    fun register(m: GoodModule) { /* hook for future external plugins */ }
}
