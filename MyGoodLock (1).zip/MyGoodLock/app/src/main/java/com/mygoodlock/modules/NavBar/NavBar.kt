package com.mygoodlock.modules.NavBar
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import com.mygoodlock.core.*

object NavBar : GoodModule {
    override val id = "navbar"; override val title = "NavBar"
    override val summary = "Switch navigation mode (needs ADB grant, experimental)"
    @Composable override fun Screen() {
        val c = LocalContext.current
        Column {
            if (!Secure.granted(c)) Text("Run once: adb shell pm grant com.mygoodlock android.permission.WRITE_SECURE_SETTINGS")
            // AOSP key; realme UI also uses hide_navigationbar_enable. Verify on your device.
            Button({ Secure.putInt(c, "navigation_mode", 2); Secure.putInt(c, "hide_navigationbar_enable", 2) }) { Text("Gestures") }
            Button({ Secure.putInt(c, "navigation_mode", 0); Secure.putInt(c, "hide_navigationbar_enable", 0) }) { Text("3-button") }
        }
    }
}
