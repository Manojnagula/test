package com.mygoodlock
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mygoodlock.core.*

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        AppSettings.init(this); ThemeEngine.load()
        setContent { MyTheme { Surface(Modifier.fillMaxSize()) { Root() } } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Root() {
    var open by remember { mutableStateOf<GoodModule?>(null) }
    BackHandlerCompat(open != null) { open = null }
    Scaffold(topBar = { TopAppBar(title = { Text(open?.title ?: "MyGoodLock") }) }) { pad ->
        Box(Modifier.padding(pad).padding(16.dp)) {
            val m = open
            if (m == null) LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(PluginManager.all) { mod ->
                    Card(Modifier.fillMaxWidth().clickable { open = mod }) {
                        Column(Modifier.padding(16.dp)) {
                            Text(mod.title, style = MaterialTheme.typography.titleMedium)
                            Text(mod.summary, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            } else m.Screen()
        }
    }
}

@Composable
fun BackHandlerCompat(enabled: Boolean, onBack: () -> Unit) =
    androidx.activity.compose.BackHandler(enabled, onBack)
