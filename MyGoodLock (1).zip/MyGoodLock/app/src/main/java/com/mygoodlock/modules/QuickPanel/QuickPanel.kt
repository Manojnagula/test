package com.mygoodlock.modules.QuickPanel
import android.content.Context
import android.hardware.camera2.CameraManager
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.mygoodlock.core.GoodModule

object QuickPanel : GoodModule {
    override val id = "quickpanel"; override val title = "QuickPanel"
    override val summary = "Custom Quick Settings tiles (Torch+)"
    @Composable override fun Screen() {
        Text("Swipe down → pencil/edit icon → drag the 'Torch+' tile into your panel.")
    }
}

class TorchTile : TileService() {
    private var on = false
    override fun onStartListening() { qsTile?.apply { state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE; updateTile() } }
    override fun onClick() {
        val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        on = !on
        runCatching { cm.setTorchMode(cm.cameraIdList[0], on) }
        onStartListening()
    }
}
