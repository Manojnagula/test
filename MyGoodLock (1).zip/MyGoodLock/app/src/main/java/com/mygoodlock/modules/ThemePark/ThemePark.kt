package com.mygoodlock.modules.ThemePark
import android.app.WallpaperManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.mygoodlock.core.*

fun applyWallpaper(c: android.content.Context, uri: Uri, flag: Int) {
    c.contentResolver.openInputStream(uri)?.use {
        WallpaperManager.getInstance(c).setStream(it, null, true, flag)
    }
}

object ThemePark : GoodModule {
    override val id = "themepark"; override val title = "ThemePark"
    override val summary = "Accent colours, Material You, home wallpaper"
    private val colors = listOf(0xFF6750A4, 0xFFE53935, 0xFF1E88E5, 0xFF43A047, 0xFFFB8C00, 0xFFD81B60).map { it.toInt() }

    @Composable override fun Screen() {
        val c = LocalContext.current
        val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
            it?.let { u -> applyWallpaper(c, u, WallpaperManager.FLAG_SYSTEM) }
        }
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Row { Text("Use Material You colours", Modifier.weight(1f))
                Switch(ThemeEngine.dynamic, { ThemeEngine.setDynamic(it) }) }
            Text("App accent")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                colors.forEach { col -> Box(Modifier.size(40.dp).clip(CircleShape).background(Color(col))
                    .clickable { ThemeEngine.setAccent(col) }) }
            }
            Button({ pick.launch("image/*") }) { Text("Set home wallpaper") }
        }
    }
}
