package com.mygoodlock.modules.LockStar
import android.app.WallpaperManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import com.mygoodlock.core.GoodModule
import com.mygoodlock.modules.ThemePark.applyWallpaper

object LockStar : GoodModule {
    override val id = "lockstar"; override val title = "LockStar"
    override val summary = "Lock-screen wallpaper (clock style is controlled by realme UI)"
    @Composable override fun Screen() {
        val c = LocalContext.current
        val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
            it?.let { u -> applyWallpaper(c, u, WallpaperManager.FLAG_LOCK) }
        }
        Column {
            Button({ pick.launch("image/*") }) { Text("Set lock wallpaper") }
            Text("Clock/widget layout can't be changed by third-party apps on realme UI.",
                style = MaterialTheme.typography.bodySmall)
        }
    }
}
