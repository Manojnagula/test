# MyGoodLock (realme narzo 70 5G, Android 16 / realme UI 7 (API 36, AGP 8.9.1+, Gradle 8.11.1+))
Open in Android Studio → Run. For StatusBar/NavBar run once:
adb shell pm grant com.mygoodlock android.permission.WRITE_SECURE_SETTINGS
