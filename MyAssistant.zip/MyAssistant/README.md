# My Assistant (Bixby-style Android agent)

Voice -> Claude (tool use) -> Android actions. Open this folder in Android Studio (Ladybug or newer), let Gradle sync, run on your phone.

## First-run setup
1. Paste your Anthropic API key in the app (personal testing only; for a real app, put it on your own backend).
2. Grant the permission prompts (mic, contacts, calendar, photos, phone).
3. Tap **Accessibility** and enable "My Assistant" (needed for screenshot, tapping, reading the screen).
4. Tap **Set as assistant** -> Default digital assistant app -> My Assistant (path varies on Realme UI).
5. Tap **Index photos** once (ideally while charging). Gallery search runs fully on-device.
6. Optional, for dark mode control: `adb shell pm grant com.example.myassistant android.permission.WRITE_SECURE_SETTINGS`
7. Realme/ColorOS: allow auto-start and set battery usage to "Unrestricted" for the app.

## Try
"Set an alarm for 6:30", "Call Mom", "Set brightness to 30", "Silent mode", "Open Spotify",
"Show photos with the beach", "Show my Aadhaar card", "Why is my phone hot?", "Turn on Wi-Fi" (opens quick settings and taps the tile).

## Privacy
- Photo labels and OCR text are stored only in the app's private database; only your spoken query and a result count go to Claude.
- read_screen sends visible screen text to Claude. Don't use it on banking or OTP screens.
- Messages are only drafted (you tap Send). Add confirmation prompts before extending destructive tools.

## Upgrading gallery search
ML Kit's built-in labels are coarse (beach, dog, tower...). For precise queries like "lighthouse", add a MobileCLIP/SigLIP TFLite model, store image embeddings in GalleryDb, and rank by cosine similarity in `GalleryDb.search`.
