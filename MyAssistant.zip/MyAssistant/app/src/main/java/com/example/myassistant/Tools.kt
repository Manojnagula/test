package com.example.myassistant

import android.app.NotificationManager
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Environment
import android.os.PowerManager
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale

class Tools(private val ctx: Context) {

    // ---------- tool schemas sent to Claude ----------
    private fun p(type: String, desc: String, enum: List<String>? = null): JSONObject {
        val o = JSONObject().put("type", type).put("description", desc)
        if (enum != null) o.put("enum", JSONArray(enum))
        return o
    }
    private fun t(name: String, desc: String, props: Map<String, JSONObject> = emptyMap(), req: List<String> = emptyList()): JSONObject {
        val pr = JSONObject(); props.forEach { (k, v) -> pr.put(k, v) }
        return JSONObject().put("name", name).put("description", desc).put(
            "input_schema", JSONObject().put("type", "object").put("properties", pr).put("required", JSONArray(req))
        )
    }

    fun definitions(): JSONArray = JSONArray().apply {
        put(t("set_alarm", "Set an alarm (24h clock).", mapOf("hour" to p("integer", "0-23"), "minute" to p("integer", "0-59"), "label" to p("string", "Label")), listOf("hour")))
        put(t("set_timer", "Start a countdown timer.", mapOf("seconds" to p("integer", "Duration in seconds"), "label" to p("string", "Label")), listOf("seconds")))
        put(t("call", "Call a contact name or phone number.", mapOf("contact_or_number" to p("string", "Name or number")), listOf("contact_or_number")))
        put(t("send_sms", "Open an SMS draft for a contact or number. The user taps Send.", mapOf("contact_or_number" to p("string", "Name or number"), "message" to p("string", "Text")), listOf("contact_or_number", "message")))
        put(t("open_app", "Open an installed app by name.", mapOf("name" to p("string", "App name")), listOf("name")))
        put(t("create_calendar_event", "Open a pre-filled calendar event.", mapOf("title" to p("string", "Title"), "start" to p("string", "Local time, format yyyy-MM-dd HH:mm"), "duration_minutes" to p("integer", "Default 60")), listOf("title", "start")))
        put(t("get_schedule", "List calendar events for the next N days.", mapOf("days" to p("integer", "Default 1"))))
        put(t("set_brightness", "Set screen brightness percent.", mapOf("percent" to p("integer", "0-100")), listOf("percent")))
        put(t("set_screen_timeout", "Set screen-off timeout in seconds.", mapOf("seconds" to p("integer", "e.g. 30, 60, 600")), listOf("seconds")))
        put(t("set_ringer", "Set ringer mode.", mapOf("mode" to p("string", "Mode", listOf("normal", "vibrate", "silent"))), listOf("mode")))
        put(t("set_do_not_disturb", "Turn Do Not Disturb on/off.", mapOf("enabled" to p("boolean", "on/off")), listOf("enabled")))
        put(t("set_dark_mode", "Turn system dark mode on/off.", mapOf("enabled" to p("boolean", "on/off")), listOf("enabled")))
        put(t("flashlight", "Turn the flashlight on/off.", mapOf("enabled" to p("boolean", "on/off")), listOf("enabled")))
        put(t("media_control", "Control current media playback.", mapOf("action" to p("string", "Action", listOf("play", "pause", "play_pause", "next", "previous"))), listOf("action")))
        put(t("play_music", "Search and play music in the default music app.", mapOf("query" to p("string", "Song, artist or playlist")), listOf("query")))
        put(t("open_settings", "Open a settings screen. Use for Wi-Fi/Bluetooth/airplane/mobile data toggles, then use screen_action if the user wants the toggle pressed.", mapOf("page" to p("string", "Page", listOf("wifi", "bluetooth", "airplane", "display", "sound", "battery", "location", "nfc", "accessibility", "main"))), listOf("page")))
        put(t("device_status", "Battery, temperature, charging, brightness, timeout, ringer, dark mode, power saver, free storage. Use for troubleshooting questions."))
        put(t("search_gallery",
            "Search the user's photos on-device. Expand the request into several lowercase English keywords and synonyms (e.g. lighthouse -> lighthouse, tower, sea, coast). For ID documents set document_type. Matching photos are shown on screen; only a count is returned.",
            mapOf("keywords" to JSONObject().put("type", "array").put("items", JSONObject().put("type", "string")).put("description", "Keywords and synonyms"),
                "document_type" to p("string", "Optional ID type", listOf("aadhaar", "pan", "passport", "driving_licence", "voter_id")),
                "limit" to p("integer", "Max photos, default 30"))))
        put(t("index_gallery", "Start or resume indexing of new photos in the background. Returns how many are indexed."))
        put(t("screen_action",
            "Control the phone UI via the accessibility service. read_screen returns visible text; click_text taps an element by its text; type_text types into the focused field. To toggle Wi-Fi etc: quick_settings, then click_text 'Wi-Fi'.",
            mapOf("action" to p("string", "Action", listOf("back", "home", "recents", "notifications", "quick_settings", "screenshot", "lock_screen", "read_screen", "click_text", "type_text")),
                "text" to p("string", "Text for click_text / type_text")), listOf("action")))
    }

    // ---------- execution ----------
    fun execute(name: String, a: JSONObject): String = when (name) {
        "set_alarm" -> setAlarm(a)
        "set_timer" -> setTimer(a)
        "call" -> call(a)
        "send_sms" -> sendSms(a)
        "open_app" -> openApp(a.getString("name"))
        "create_calendar_event" -> createEvent(a)
        "get_schedule" -> getSchedule(a.optInt("days", 1))
        "set_brightness" -> setBrightness(a.getInt("percent"))
        "set_screen_timeout" -> setTimeout(a.getInt("seconds"))
        "set_ringer" -> setRinger(a.getString("mode"))
        "set_do_not_disturb" -> setDnd(a.getBoolean("enabled"))
        "set_dark_mode" -> setDark(a.getBoolean("enabled"))
        "flashlight" -> flashlight(a.getBoolean("enabled"))
        "media_control" -> media(a.getString("action"))
        "play_music" -> playMusic(a.getString("query"))
        "open_settings" -> openSettings(a.getString("page"))
        "device_status" -> deviceStatus()
        "search_gallery" -> searchGallery(a)
        "index_gallery" -> { GalleryIndexWorker.enqueue(ctx); "Indexing started. Photos indexed so far: ${GalleryDb(ctx).count()}" }
        "screen_action" -> screenAction(a.getString("action"), a.optString("text"))
        else -> "Unknown tool: $name"
    }

    private fun launch(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i) }
    private fun granted(perm: String) = ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED

    private fun setAlarm(a: JSONObject): String {
        val h = a.getInt("hour"); val m = a.optInt("minute", 0)
        launch(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Alarm")).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return "Alarm set for %02d:%02d".format(h, m)
    }

    private fun setTimer(a: JSONObject): String {
        val s = a.getInt("seconds")
        launch(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, s)
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Timer")).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return "Timer started for $s seconds"
    }

    private fun lookupNumber(name: String): String? {
        if (!granted(android.Manifest.permission.READ_CONTACTS)) return null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
        )?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    private fun resolve(target: String): String? =
        if (target.any { it.isLetter() }) lookupNumber(target) else target

    private fun call(a: JSONObject): String {
        val target = a.getString("contact_or_number")
        val number = resolve(target) ?: return "Could not find a number for '$target' (check contacts permission)"
        val action = if (granted(android.Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
        launch(Intent(action, Uri.parse("tel:" + Uri.encode(number))))
        return "Calling $target"
    }

    private fun sendSms(a: JSONObject): String {
        val target = a.getString("contact_or_number")
        val number = resolve(target) ?: return "Could not find a number for '$target'"
        launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))).putExtra("sms_body", a.getString("message")))
        return "Message drafted for $target. The user must tap Send."
    }

    private fun openApp(name: String): String {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val q = name.lowercase()
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) } ?: return "No app matching '$name'"
        val i = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return "Cannot launch $name"
        launch(i)
        return "Opened ${match.loadLabel(pm)}"
    }

    private fun createEvent(a: JSONObject): String {
        val start = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).parse(a.getString("start"))?.time ?: return "Bad date format"
        val end = start + a.optInt("duration_minutes", 60) * 60_000L
        launch(Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, a.getString("title"))
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end))
        return "Calendar event opened for confirmation"
    }

    private fun getSchedule(days: Int): String {
        if (!granted(android.Manifest.permission.READ_CALENDAR)) return "Calendar permission not granted"
        val now = System.currentTimeMillis()
        val fmt = SimpleDateFormat("EEE d MMM HH:mm", Locale.getDefault())
        val sb = StringBuilder()
        CalendarContract.Instances.query(
            ctx.contentResolver, arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN),
            now, now + days * 86_400_000L
        )?.use { c -> while (c.moveToNext()) sb.append(fmt.format(c.getLong(1))).append(" - ").append(c.getString(0)).append('\n') }
        return sb.toString().ifBlank { "No events" }
    }

    private fun needWriteSettings(): Boolean {
        if (Settings.System.canWrite(ctx)) return false
        launch(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
        return true
    }

    private fun setBrightness(pct: Int): String {
        if (needWriteSettings()) return "Needs 'Modify system settings' permission. Opened the page; ask again after enabling."
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, pct.coerceIn(0, 100) * 255 / 100)
        return "Brightness set to $pct%"
    }

    private fun setTimeout(sec: Int): String {
        if (needWriteSettings()) return "Needs 'Modify system settings' permission. Opened the page; ask again after enabling."
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, sec * 1000)
        return "Screen timeout set to $sec seconds"
    }

    private fun setRinger(mode: String): String {
        val am = ctx.getSystemService(AudioManager::class.java)
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (mode == "silent" && !nm.isNotificationPolicyAccessGranted) {
            launch(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            return "Needs Do Not Disturb access. Opened the page; ask again after enabling."
        }
        am.ringerMode = when (mode) { "silent" -> AudioManager.RINGER_MODE_SILENT; "vibrate" -> AudioManager.RINGER_MODE_VIBRATE; else -> AudioManager.RINGER_MODE_NORMAL }
        return "Ringer set to $mode"
    }

    private fun setDnd(on: Boolean): String {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            launch(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            return "Needs Do Not Disturb access. Opened the page; ask again after enabling."
        }
        nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_NONE else NotificationManager.INTERRUPTION_FILTER_ALL)
        return "Do Not Disturb ${if (on) "on" else "off"}"
    }

    private fun setDark(on: Boolean): String {
        if (granted("android.permission.WRITE_SECURE_SETTINGS")) {
            Settings.Secure.putInt(ctx.contentResolver, "ui_night_mode", if (on) 2 else 1)
            return "Dark mode ${if (on) "on" else "off"}"
        }
        launch(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        return "Opened Display settings. For automatic control, grant WRITE_SECURE_SETTINGS once via ADB (see README)."
    }

    private fun flashlight(on: Boolean): String {
        val cm = ctx.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            ?: return "No flashlight found"
        cm.setTorchMode(id, on)
        return "Flashlight ${if (on) "on" else "off"}"
    }

    private fun media(action: String): String {
        val am = ctx.getSystemService(AudioManager::class.java)
        val code = when (action) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY; "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT; "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return "Sent $action"
    }

    private fun playMusic(q: String): String = try {
        launch(Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).putExtra(SearchManager.QUERY, q))
        "Asked the music app to play '$q'"
    } catch (e: Exception) { "No music app could handle that: ${e.message}" }

    private fun openSettings(page: String): String {
        val i = when (page) {
            "wifi" -> Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "airplane" -> Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
            "display" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            "sound" -> Intent(Settings.ACTION_SOUND_SETTINGS)
            "battery" -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
            "location" -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            "nfc" -> Intent(Settings.ACTION_NFC_SETTINGS)
            "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            else -> Intent(Settings.ACTION_SETTINGS)
        }
        launch(i)
        return "Opened $page settings"
    }

    private fun deviceStatus(): String {
        val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = (b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1) * 100 / (b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100)
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val charging = (b?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        val cr = ctx.contentResolver
        val dark = (ctx.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
        val ringer = ctx.getSystemService(AudioManager::class.java).ringerMode
        val saver = ctx.getSystemService(PowerManager::class.java).isPowerSaveMode
        val freeGb = Environment.getDataDirectory().freeSpace / 1_000_000_000.0
        return "battery=$level% charging=$charging temp=${temp}C powerSaver=$saver " +
            "brightness=${Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, -1) * 100 / 255}% " +
            "screenTimeoutSec=${Settings.System.getInt(cr, Settings.System.SCREEN_OFF_TIMEOUT, 0) / 1000} " +
            "ringerMode=$ringer(0=silent,1=vibrate,2=normal) darkMode=$dark freeStorage=%.1fGB".format(freeGb)
    }

    private fun searchGallery(a: JSONObject): String {
        val kw = a.optJSONArray("keywords")?.let { arr -> (0 until arr.length()).map { arr.getString(it) } } ?: emptyList()
        val doc = a.optString("document_type").ifBlank { null }
        val db = GalleryDb(ctx)
        if (db.count() == 0) { GalleryIndexWorker.enqueue(ctx); return "Gallery is not indexed yet. Indexing started; try again in a few minutes." }
        val ids = db.search(kw, doc, a.optInt("limit", 30))
        UiBridge.onImages?.invoke(ids.map { GalleryDb.uriOf(it) })
        return "Found ${ids.size} matching photos, now shown on screen (${db.count()} photos indexed)."
    }

    private fun screenAction(action: String, text: String): String {
        val s = ControlAccessibilityService.instance
        if (s == null) { launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return "Accessibility service is off. Opened settings; enable 'My Assistant'." }
        return when (action) {
            "read_screen" -> s.readScreen()
            "click_text" -> if (s.clickText(text)) "Clicked '$text'" else "Could not find a clickable '$text'"
            "type_text" -> if (s.typeText(text)) "Typed" else "No focused text field"
            else -> if (s.global(action)) "Done: $action" else "Failed: $action"
        }
    }
}
