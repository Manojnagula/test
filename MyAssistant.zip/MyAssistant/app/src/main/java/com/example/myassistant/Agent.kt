package com.example.myassistant

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class Agent(private val ctx: Context, private val tools: Tools) {
    var apiKey = ""
    var model = "claude-sonnet-5-5"

    private val http = OkHttpClient.Builder().readTimeout(90, TimeUnit.SECONDS).build()
    private var messages = JSONArray()
    private val toolDefs: JSONArray = tools.definitions().put(
        JSONObject().put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 3)
    )

    private val system = """You are a voice assistant running on the user's Android phone. Use the tools to act on the phone.
Your replies are spoken aloud: keep them to one or two short sentences, no markdown.
Break multi-part requests into several tool calls. Only call or message people the user explicitly named.
For photo searches, expand the request into many keywords and synonyms. Use device_status when asked why the phone is slow, hot or draining.
If a tool says a permission is missing, tell the user what to enable."""

    fun reset() { messages = JSONArray() }

    suspend fun run(userText: String, status: (String) -> Unit): String = withContext(Dispatchers.IO) {
        messages.put(JSONObject().put("role", "user").put("content", userText))
        repeat(12) {
            val resp = call()
            val content = resp.getJSONArray("content")
            messages.put(JSONObject().put("role", "assistant").put("content", content))
            when (resp.optString("stop_reason")) {
                "tool_use" -> {
                    val results = JSONArray()
                    for (i in 0 until content.length()) {
                        val b = content.getJSONObject(i)
                        if (b.getString("type") != "tool_use") continue
                        val name = b.getString("name")
                        status("→ $name")
                        val out = try { tools.execute(name, b.getJSONObject("input")) } catch (e: Exception) { "Error: ${e.message}" }
                        results.put(JSONObject().put("type", "tool_result").put("tool_use_id", b.getString("id")).put("content", out))
                    }
                    messages.put(JSONObject().put("role", "user").put("content", results))
                }
                "pause_turn" -> {}  // server-side web search still running; just continue
                else -> return@withContext textOf(content)
            }
        }
        "I stopped after too many steps."
    }

    private fun textOf(content: JSONArray): String =
        (0 until content.length()).map { content.getJSONObject(it) }
            .filter { it.getString("type") == "text" }.joinToString(" ") { it.getString("text") }.ifBlank { "Done." }

    private fun call(): JSONObject {
        val body = JSONObject().put("model", model).put("max_tokens", 1024).put("system", system)
            .put("tools", toolDefs).put("messages", messages)
        val req = Request.Builder().url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", apiKey).header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        http.newCall(req).execute().use { r ->
            val s = r.body?.string() ?: ""
            if (!r.isSuccessful) error("API ${r.code}: ${s.take(300)}")
            return JSONObject(s)
        }
    }
}
