package com.example.myassistant

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import android.provider.MediaStore
import android.util.Size
import androidx.work.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/** Detects ID documents from OCR text. Everything stays on the device. */
object DocClassifier {
    private val aadhaar = Regex("\\b\\d{4}\\s\\d{4}\\s\\d{4}\\b")
    private val pan = Regex("\\b[A-Z]{5}[0-9]{4}[A-Z]\\b")
    fun classify(raw: String): String {
        val t = raw.lowercase()
        return when {
            "aadhaar" in t || "uidai" in t || (aadhaar.containsMatchIn(raw) && "government of india" in t) -> "aadhaar"
            pan.containsMatchIn(raw) || "permanent account number" in t -> "pan"
            "p<ind" in t || ("passport" in t && "republic of india" in t) -> "passport"
            "driving licence" in t || "driving license" in t -> "driving_licence"
            "election commission of india" in t -> "voter_id"
            else -> ""
        }
    }
}

class GalleryDb(ctx: Context) : SQLiteOpenHelper(ctx, "gallery.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE photos(id INTEGER PRIMARY KEY, labels TEXT, ocr TEXT, doc TEXT, taken INTEGER)")
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    fun has(id: Long): Boolean =
        readableDatabase.rawQuery("SELECT 1 FROM photos WHERE id=?", arrayOf(id.toString())).use { it.moveToFirst() }

    fun count(): Int =
        readableDatabase.rawQuery("SELECT COUNT(*) FROM photos", null).use { it.moveToFirst(); it.getInt(0) }

    fun put(id: Long, labels: String, ocr: String, doc: String, taken: Long) {
        val v = ContentValues().apply {
            put("id", id); put("labels", labels); put("ocr", ocr.lowercase()); put("doc", doc); put("taken", taken)
        }
        writableDatabase.insertWithOnConflict("photos", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun search(keywords: List<String>, doc: String?, limit: Int): List<Long> {
        val kws = keywords.map { it.lowercase().trim() }.filter { it.isNotEmpty() }
        val out = ArrayList<Pair<Long, Int>>()
        readableDatabase.rawQuery("SELECT id, labels, ocr, doc FROM photos ORDER BY taken DESC", null).use { c ->
            while (c.moveToNext()) {
                if (doc != null && c.getString(3) != doc) continue
                val labels = c.getString(1) ?: ""
                val ocr = c.getString(2) ?: ""
                val score = kws.fold(0) { acc, k ->
                    acc + (if (labels.contains(k)) 3 else 0) + (if (ocr.contains(k)) 1 else 0)
                }
                if (doc != null || score > 0) out.add(c.getLong(0) to score)
            }
        }
        return out.sortedByDescending { it.second }.take(limit).map { it.first }
    }

    companion object {
        fun uriOf(id: Long): Uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
    }
}

class GalleryIndexer(private val ctx: Context) {
    suspend fun run() = withContext(Dispatchers.Default) {
        val db = GalleryDb(ctx)
        val labeler = ImageLabeling.getClient(ImageLabelerOptions.Builder().setConfidenceThreshold(0.6f).build())
        val ocr = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val photos = ArrayList<Pair<Long, Long>>()
        ctx.contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_TAKEN),
            null, null, "${MediaStore.Images.Media.DATE_ADDED} DESC"
        )?.use { c -> while (c.moveToNext()) photos.add(c.getLong(0) to c.getLong(1)) }

        for ((id, taken) in photos) {
            ensureActive()
            if (db.has(id)) continue
            var labels = ""
            var text = ""
            try {
                val bmp = ctx.contentResolver.loadThumbnail(GalleryDb.uriOf(id), Size(1280, 1280), null)
                val img = InputImage.fromBitmap(bmp, 0)
                labels = labeler.process(img).await().joinToString(",") { it.text.lowercase() }
                text = ocr.process(img).await().text
            } catch (e: Exception) { /* store empty row so we do not retry forever */ }
            db.put(id, labels, text, DocClassifier.classify(text), taken)
        }
    }
}

class GalleryIndexWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        GalleryIndexer(applicationContext).run()
        return Result.success()
    }
    companion object {
        fun enqueue(ctx: Context) {
            val req = OneTimeWorkRequestBuilder<GalleryIndexWorker>()
                .setConstraints(Constraints.Builder().setRequiresBatteryNotLow(true).build()).build()
            WorkManager.getInstance(ctx).enqueueUniqueWork("gallery_index", ExistingWorkPolicy.KEEP, req)
        }
    }
}

object UiBridge { var onImages: ((List<Uri>) -> Unit)? = null }
